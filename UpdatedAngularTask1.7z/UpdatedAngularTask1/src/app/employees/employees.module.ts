import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmpDisplayComponent } from './emp-display/emp-display.component';
import { EmpListComponent } from './emp-list/emp-list.component';




@NgModule({
  declarations: [
    EmpDisplayComponent,EmpListComponent
    
  ],
  imports: [
    CommonModule
  ],
  exports:[EmpDisplayComponent,EmpListComponent]
 
})
export class EmployeesModule { }
export class Employee{
  empName: string
  empID: string
  empEmail: string
  empAge: string
  empDesignation: string

  constructor(name: string, id:string, email:string, age:string, desig: string){
    this.empAge=age;
    this.empDesignation=desig;
    this.empEmail=email;
    this.empID=id;
    this.empName=name;
  }
}