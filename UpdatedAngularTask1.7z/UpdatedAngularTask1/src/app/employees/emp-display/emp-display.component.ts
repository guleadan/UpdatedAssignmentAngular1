import { Component, OnInit,Input } from '@angular/core';
import { EmployeesService } from 'src/app/employees.service';
import { Employee } from '../employees.module';

@Component({
  selector: 'app-emp-display',
  templateUrl: './emp-display.component.html',
  styleUrls: ['./emp-display.component.css']
})
export class EmpDisplayComponent implements OnInit {
public empList!: Employee[];
public check: Boolean;
  @Input() sample:Employee;
  constructor(private _employeeService:EmployeesService) { 
    this.check= false;
    this.sample={empName:"",
    empAge:"",
    empDesignation:"",
    empEmail:"",
    empID:""
  }
  

  
}
  ngOnInit(): void {
    this.empList=this._employeeService.getEmpList();
    throw new Error('Method not implemented.');
  }
  showPrevious(){
    const index= this.empList.findIndex(x => x.empName === this.sample.empName);
    alert(index);
    this.sample= this.empList[index-1];

  }
  showNext(){
    const index= this.empList.findIndex(x => x.empName === this.sample.empName);
    alert(this.empList.length);
    if((index+1)!=this.empList.length){
      this.sample= this.empList[index+1];

    }
    else{
      alert("Problem!")
    }
    
  }
}

