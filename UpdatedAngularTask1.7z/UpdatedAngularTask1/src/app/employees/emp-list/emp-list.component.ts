import { Component, OnInit } from '@angular/core';
import { EmployeesService } from 'src/app/employees.service';
import { Employee } from '../employees.module';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit { employee:Employee;
  public empList: any[];
    constructor(private _employeeService:EmployeesService) {
      this.employee={empName:"",
      empAge:"",
      empDesignation:"",
      empEmail:"",
      empID:""
    };
    this.empList=this._employeeService.getEmpList();

      // this.empList=[
      //   {empName:"Rida Fatima",
      //   empAge:"22",
      //   empDesignation:"Web Developer",
      //   empEmail:"rida@gmail.com",
      //   empID:"4044"
      // },
      // {empName:"Iram Fiyaz",
      //   empAge:"23",
      //   empDesignation:"Quality Engineer",
      //   empEmail:"iram@gmail.com",
      //   empID:"4043"
      // },
      // {empName:"Hamza Mushtaq",
      //   empAge:"22",
      //   empDesignation:"Full Stack Developer",
      //   empEmail:"hamza@gmail.com",
      //   empID:"4033"
      // }
      // ];
      
      
  
     }
  

  ngOnInit(): void {
    this.empList=this._employeeService.getEmpList();
  }
  dispData(emp:Employee){
    console.log(emp);
   this.employee=emp
  }
  challo(){
    alert(this.empList[0]);
  }

}
