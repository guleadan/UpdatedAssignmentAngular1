import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  constructor() { }
  getEmpList() {
    return [
    {empName:"Rida Fatima",
    empAge:"22",
    empDesignation:"Web Developer",
    empEmail:"rida@gmail.com",
    empID:"4044"
  },
  {empName:"Iram Fiyaz",
    empAge:"23",
    empDesignation:"Quality Engineer",
    empEmail:"iram@gmail.com",
    empID:"4043"
  },
  {empName:"Hamza Mushtaq",
    empAge:"22",
    empDesignation:"Full Stack Developer",
    empEmail:"hamza@gmail.com",
    empID:"4033"
  },
  {empName:"Muhammad Nadeem",
    empAge:"23",
    empDesignation:"Software Eningeer",
    empEmail:"nadeem@gmail.com",
    empID:"4005"
  }
  ];
  
} 

}
